package co.edu.uniquindio.proyecto.entidades;

public enum MedioPago {

    CREDITO, DEBITO, EFECTIVO, PAYPAL, PSE;
}
