package co.edu.uniquindio.proyecto.repositorios;

import co.edu.uniquindio.proyecto.entidades.SubastaUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubastaUsuarioRepo extends JpaRepository<SubastaUsuario, String> {
}
